<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

     <link href="css/style.css" rel="stylesheet">
    <title>Hello, world!</title>
  </head>
  <body>

    <header style="background-image:url(img/header.svg);">
        <div class="navigation">
            <ul>
                <li class="logo"> <a href="#">  <img src="img/logo.png" alt="logo"> </a> </li>
                <li> <a href="#">Home</a> </li>
                <li> <a href="#">About</a> </li>
                <li> <a href="#">Contact</a> </li>
                <li> <a href="#">Gallery</a> </li>
                <li> <a href="#">Team</a> </li>
                <li> <a href="#">Projects</a> </li>
                <li> <a href="#">Policy</a> </li>

            </ul>
        </div>

        <br>

        <div class="container">
             <div class="header_content">
                  <h1>Welcome to Official Hotboy</h1>
                  <hr>
                  <p>
                     ipsum dolor sit amet, consectetur adipisicing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore
                       magna aliqua. Ut enim ad minim veniam, quis nostrud
                       exercitation ullamco laboris nisi ut aliquip
                       ex ea commodo consequat.ullamco laboris nisi ut aliquip
                       ex ea commodo consequat.ullamco laboris nisi ut aliquip
                       ex ea commodo consequat.

                  </p>
                  <div align="center">
                      <a class="btn btn-white btn-lg" href="#">Get Started Now</a>
                  </div>
             </div>
        </div>
    </header>

<br><br><br><br><br><br>

<div class="container">
    <h1>Main Website Content should come here </h1>
</div>

<br><br><br><br><br><br><br><br><br><br>
<footer style="background-image:url(img/footer.svg);">

    <div class="container footer_content">
        <div class="row">
            <div class="col-md-4">
                 <h1>Follow us</h1>
                 <ul class="footer_list">
                        <li> <a href="#"> Facebook </a> </li>
                        <li> <a href="#"> Twitter </a> </li>
                        <li> <a href="#"> Instagram </a> </li>
                        <li> <a href="#"> Youtube </a> </li>
                        <li> <a href="#"> Linkin </a> </li>
                 </ul>
            </div>

            <div class="col-md-4">
                 <h1>Quick Links</h1>
                 <ul class="footer_list">
                        <li> <a href="#"> About </a> </li>
                        <li> <a href="#"> Contact us </a> </li>
                        <li> <a href="#"> Gallary </a> </li>
                        <li> <a href="#"> Youtube </a> </li>
                        <li> <a href="#"> Linkin </a> </li>
                 </ul>
            </div>


            <div class="col-md-4">
                 <h1>Follow us</h1>
                 <ul class="footer_list">
                        <li> <a href="#"> Facebook </a> </li>
                        <li> <a href="#"> Twitter </a> </li>
                        <li> <a href="#"> Instagram </a> </li>
                        <li> <a href="#"> Youtube </a> </li>
                        <li> <a href="#"> Linkin </a> </li>
                 </ul>
            </div>


        </div>
    </div>
<div align="center">
    <p style="color:#fff;font-size:20px;"> Copyright &copy; Official Hotboy <?php echo date("Y"); ?> </p>
</div>
</footer>






  </body>
</html>
